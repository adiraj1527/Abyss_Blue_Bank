<!DOCTYPE html>
<html lang="en">

<?php $active = "";
$title = "Cards";
include "header.php" ?>

<main id="main">

  <!-- ======= Breadcrumbs ======= -->
  <section class="breadcrumbs">
    <div class="container">

      <div class="d-flex justify-content-between align-items-center">
        <ol>
          <li><a href="../">Home</a></li>
          <li>Cards</li>
        </ol>
      </div>

    </div>
  </section><!-- End Breadcrumbs -->

  <section class="inner-page">
    <div class="container">
      <h1>Credit Card & Debit Card</h1>
      <p>We provide you the best credit card and debit card<br> services. With the help of these services it will be<br> much easier for you to Shop at any time without<br>
        the burdun of cash and problems of change.
      </p>
      <p>
        Our bank provide you the the best user experience<br> to shop with your card and manage them without<br> any casualties.
      </p>
    </div>
  </section>

</main><!-- End #main -->


<?php
include "footer.php";
?>

</html>