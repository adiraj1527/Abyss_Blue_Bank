<?php

// Names
define("BANKNAME", "ABYSS BLUE");
define("EMAIL", "");
define("PASSWORD", "");
define("ADDRESS", "");
define("MOBILENO", "1234567890");
define("LOCATION_CORDINATE", "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241316.6433229747!2d72.74109780863925!3d19.08252232377542!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1655905278974!5m2!1sen!2sin");
